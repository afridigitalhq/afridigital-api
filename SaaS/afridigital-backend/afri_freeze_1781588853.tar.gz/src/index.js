const { assertEntryOnly } = require("../core/runtime/guards/entry.lock"); const { scanRepo } = require("../core/runtime/guards/repo.scan"); require("../core/runtime/guards/listen.kernel");
assertEntryOnly(); // scanRepo disabled (false positives fix)


const express = require("express");
const app = express();

app.use(express.json());

const PORT = process.env.PORT || 10000;

app.get("/", (req, res) => {
  res.json({ ok: true, route: "express_alive" });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log("🚀 SINGLE SERVER ACTIVE ON", PORT);
});
