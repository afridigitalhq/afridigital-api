module.exports = require('./enhancer');
