const path = require("path");

function getDomain(file) {
  if (!file) return "unknown";

  if (file.includes("/whatsapp/pipeline")) return "whatsapp";
  if (file.includes("/whatsapp")) return "whatsapp";
  if (file.includes("/africore")) return "africore";
  if (file.includes("/agents")) return "agents";
  if (file.includes("/integrations")) return "integrations";

  return "system";
}

function classifyRequest(request, parentFile) {
  if (!request) return "external";

  // external libraries (safe)
  if (!request.startsWith(".") && !request.startsWith("/")) {
    return "external";
  }

  // resolve real path for relative imports
  try {
    const resolved = path.resolve(path.dirname(parentFile || ""), request);

    if (resolved.includes("/whatsapp")) return "whatsapp";
    if (resolved.includes("/africore")) return "africore";
    if (resolved.includes("/agents")) return "agents";
    if (resolved.includes("/integrations")) return "integrations";

    return "internal";
  } catch (e) {
    return "internal";
  }
}

function enforce(fromFile, request) {
  const from = getDomain(fromFile);
  const to = classifyRequest(request, fromFile);

  // allow safe boundaries
  if (to === "external") return;
  if (to === "internal") return;

  // enforce only REAL domain cross-talk
  if (from !== to) {
    throw new Error(`V18.1_KERNEL_BLOCK: ${from} → ${to}`);
  }
}

module.exports = { enforce };
