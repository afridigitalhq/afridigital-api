module.exports = {
  domains: {
    whatsapp: ["whatsapp"],
    africore: ["africore"],
    agents: ["agents"],
    integrations: ["integrations"]
  }
};
