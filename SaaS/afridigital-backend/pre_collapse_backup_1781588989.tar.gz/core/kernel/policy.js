const { domains } = require("./registry");

function isAllowed(from, to) {
  const allowed = domains[from] || [];
  return allowed.includes(to);
}

module.exports = { isAllowed };
